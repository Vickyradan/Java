package javaSample;

public class ParameterMethod {
	
	
	
	
	  public void Student(String name){
		  
		  System.out.println("Student name:"+"\n" +name);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ParameterMethod obj =new ParameterMethod();
		
		obj.Student("Arun");
		obj.Student("Bala");
		
	

	}

}
