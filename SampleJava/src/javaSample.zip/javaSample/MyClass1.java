package javaSample;

public class MyClass1 {

	
	public static String name = "Raja";
	static int Age =45;
	static double height =6.23;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("name value"+ name);
		System.out.println("Age value"+ Age);
		System.out.println("Height value"+ height);

	}

}
